NO IMPLEMENTADO:
    - Spinner en el fragment de Listado
    - Filtrado de bugs
    - La prioridad de los bugs son Strings, en lugar de enum (Sin embargo, comprobamos que el input sea
     sola y exclusivamente "alta" o "baja")
    - Consulta los comentarios FIXME en la clase SharedVM en el metodo poblarBugsDeProgramador

LANZA UNA EXCEPCIÓN EN TIEMPO DE EJECUCIÓN AL EJECUTAR:
 "Attempt to invoke interface method 'java.lang.Object[] java.util.Collection.toArray()' on a null object reference"
 CONSULTAR LA CLASE SharedVM, LOS COMENTARIOS FIXME EN LOS ATRIBUTOS (LA EXCEPCIÓN SE DEBE A QUE LAS LISTAS NO ESTÁN INSTANCIADAS POR DEFECTO)
